﻿ContactSample.ContactDetail = function (params) {

    var viewModel = {
        pageTitle: ko.observable(),
        contactDetail: ko.observableArray()
    };

    var createDetailContent = function (contacts) {
        viewModel.pageTitle(contacts[0].Name);
        viewModel.contactDetail(contacts);
    };

    ContactSample.db.contacts.load({
        filter: ["ContactId", params.id]
    }).done(createDetailContent);

    return viewModel;
};