﻿window.ContactSample = window.ContactSample || {};

$(function() {
    app = new DevExpress.framework.html.HtmlApplication({
        ns: ContactSample,
        viewPortNode: document.getElementById("viewPort"),
        defaultLayout: "navbar",
        navigation: [
            new DevExpress.framework.Command({
                title: "My Contacts",
                uri: "index",
                icon: "home",
                location: "navigation"
            }),
            new DevExpress.framework.Command({
                title: "About",
                uri: "about",
                icon: "about",
                location: "navigation"
            })
        ]
    });
    app.router.register(":view/:id", { view: "index", id: undefined });
    app.router.register(":view/:id", { view: "ContactDetail", id: "1" });
});
