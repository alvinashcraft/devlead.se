﻿ContactSample.index = function(params) {

    var viewModel = {
        contacts: {
            store: ContactSample.db.contacts
        }
    };

    return viewModel;
};