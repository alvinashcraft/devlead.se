﻿$(function() {
    ContactSample.db = new DevExpress.data.RestService({
        url: "http://localhost:8081/api/",
        sources: {
            contacts: {
                read: "Contacts.json"
            }
        }
    });
});